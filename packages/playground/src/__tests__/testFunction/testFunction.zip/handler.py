def handle(data):
    print('Hello World!')
    print(f'Received data: {data}')
